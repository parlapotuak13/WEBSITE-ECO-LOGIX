-- ============================================================================
-- ECO-LOGIX · SKEMA DATABASE TERPADU (KURIR + PENGIRIM + VENDOR 3PL)
-- ============================================================================
-- Cara pakai: Buka Supabase > SQL Editor > New query > Tempel seluruh isi > Run.
-- Skema ini 100% IDEMPOTEN (aman dijalankan berulang kali tanpa error).
-- ============================================================================

-- 1. TABEL VENDOR 3PL & STATE TERPADU (public.vendor_state)
create table if not exists public.vendor_state (
  id         text primary key,
  data       jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

alter table public.vendor_state enable row level security;

drop policy if exists demo_baca   on public.vendor_state;
drop policy if exists demo_tambah on public.vendor_state;
drop policy if exists demo_ubah   on public.vendor_state;
create policy demo_baca   on public.vendor_state for select to anon, authenticated using (true);
create policy demo_tambah on public.vendor_state for insert to anon, authenticated with check (true);
create policy demo_ubah   on public.vendor_state for update to anon, authenticated using (true) with check (true);

do $$ begin
  alter publication supabase_realtime add table public.vendor_state;
exception when duplicate_object then null; end $$;

insert into public.vendor_state (id) values ('eco-hemat') on conflict (id) do nothing;

-- 2. TABEL PENGIRIM (public.shipments)
-- Perbaikan: user_id dibuat opsional (nullable) dengan fallback policy anon agar
-- aplikasi tetap berjalan lancar meskipun fitur Anonymous Sign-Ins belum diaktifkan.
create table if not exists public.shipments (
  id text primary key default 'ELX-' || upper(substr(md5(gen_random_uuid()::text), 1, 6)),
  user_id uuid default auth.uid(),
  created_at timestamptz not null default now(),
  sender text not null check (char_length(sender) <= 80),
  city text not null check (char_length(city) <= 60),
  pickup_district text not null check (char_length(pickup_district) <= 60),
  pickup_address text not null check (char_length(pickup_address) <= 200),
  destination_district text not null check (char_length(destination_district) <= 60),
  destination_address text not null check (char_length(destination_address) <= 200),
  package_type text not null check (package_type in ('Dokumen','Paket kecil','Paket sedang')),
  quantity int not null check (quantity between 1 and 999),
  notes text not null default '' check (char_length(notes) <= 300),
  mode text not null check (mode in ('hijau','langsung')),
  stage int not null default 0 check (stage between 0 and 5),
  otp text not null default ((1000 + floor(random() * 9000))::int)::text
);

create index if not exists shipments_user_created_idx on public.shipments (user_id, created_at desc);
alter table public.shipments enable row level security;

drop policy if exists "baca milik sendiri"  on public.shipments;
drop policy if exists "buat milik sendiri"  on public.shipments;
drop policy if exists "ubah milik sendiri"  on public.shipments;
drop policy if exists "hapus milik sendiri" on public.shipments;
drop policy if exists "demo_shipments_all"  on public.shipments;

create policy "demo_shipments_all" on public.shipments
  for all to anon, authenticated
  using (user_id is null or (select auth.uid()) = user_id)
  with check (user_id is null or (select auth.uid()) = user_id);

do $$ begin
  alter publication supabase_realtime add table public.shipments;
exception when duplicate_object then null; end $$;

-- 3. TABEL & RPC SIMULASI KURIR (public.demo_runs & public.handover_logs)
create table if not exists public.demo_runs (
  id          uuid primary key default gen_random_uuid(),
  courier     text        not null default 'a' check (courier in ('a','b')),
  progress    integer     not null default 0  check (progress between 0 and 100),
  verified    boolean     not null default false,
  otp         text        not null check (otp ~ '^[0-9]{4}$'),
  alpha       integer     not null default 70 check (alpha between 0 and 100),
  beta        integer     not null default 30 check (beta  between 0 and 100),
  attempts    integer     not null default 0,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

create table if not exists public.handover_logs (
  id          bigint generated always as identity primary key,
  run_id      uuid        not null references public.demo_runs(id) on delete cascade,
  packages    integer     not null,
  message     text        not null,
  created_at  timestamptz not null default now()
);

create index if not exists handover_logs_run_idx on public.handover_logs (run_id, created_at);
create index if not exists demo_runs_updated_idx on public.demo_runs (updated_at);

alter table public.demo_runs     enable row level security;
alter table public.handover_logs enable row level security;
revoke all on public.demo_runs     from anon, authenticated;
revoke all on public.handover_logs from anon, authenticated;

create or replace function public.get_run(p_id uuid)
returns jsonb language sql stable security definer set search_path = public as $$
  select jsonb_build_object(
    'id', r.id, 'courier', r.courier, 'progress', r.progress,
    'verified', r.verified, 'otp', r.otp, 'alpha', r.alpha, 'beta', r.beta,
    'logs', coalesce((
      select jsonb_agg(jsonb_build_object(
               'packages', l.packages, 'message', l.message, 'created_at', l.created_at)
             order by l.created_at, l.id)
      from public.handover_logs l where l.run_id = r.id
    ), '[]'::jsonb)
  )
  from public.demo_runs r where r.id = p_id;
$$;

create or replace function public.create_run()
returns jsonb language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into public.demo_runs (otp)
  values (lpad((1000 + floor(random() * 9000))::int::text, 4, '0'))
  returning id into v_id;
  return public.get_run(v_id);
end;
$$;

create or replace function public.save_run(
  p_id uuid, p_courier text, p_progress integer, p_alpha integer, p_beta integer)
returns void language plpgsql security definer set search_path = public as $$
begin
  if p_courier not in ('a','b') then raise exception 'courier tidak valid'; end if;
  update public.demo_runs
     set courier    = p_courier,
         progress   = greatest(0, least(100, coalesce(p_progress, 0))),
         alpha      = greatest(0, least(100, coalesce(p_alpha, 70))),
         beta       = greatest(0, least(100, coalesce(p_beta, 30))),
         updated_at = now()
   where id = p_id;
end;
$$;

create or replace function public.verify_run(p_id uuid, p_otp text)
returns boolean language plpgsql security definer set search_path = public as $$
declare r public.demo_runs;
begin
  select * into r from public.demo_runs where id = p_id for update;
  if not found or r.verified or r.attempts >= 10 then return false; end if;
  if r.otp <> coalesce(p_otp, '') then
    update public.demo_runs set attempts = attempts + 1, updated_at = now() where id = p_id;
    return false;
  end if;
  update public.demo_runs set verified = true, updated_at = now() where id = p_id;
  insert into public.handover_logs (run_id, packages, message)
  values (p_id, 12, '12 paket diserahterimakan dan diverifikasi');
  return true;
end;
$$;

create or replace function public.reset_run(p_id uuid)
returns jsonb language plpgsql security definer set search_path = public as $$
begin
  delete from public.handover_logs where run_id = p_id;
  update public.demo_runs
     set courier = 'a', progress = 0, verified = false, alpha = 70, beta = 30,
         attempts = 0,
         otp = lpad((1000 + floor(random() * 9000))::int::text, 4, '0'),
         updated_at = now()
   where id = p_id;
  return public.get_run(p_id);
end;
$$;

revoke all on function public.get_run(uuid) from public;
revoke all on function public.create_run() from public;
revoke all on function public.save_run(uuid, text, integer, integer, integer) from public;
revoke all on function public.verify_run(uuid, text) from public;
revoke all on function public.reset_run(uuid) from public;

grant execute on function public.get_run(uuid) to anon, authenticated;
grant execute on function public.create_run() to anon, authenticated;
grant execute on function public.save_run(uuid, text, integer, integer, integer) to anon, authenticated;
grant execute on function public.verify_run(uuid, text) to anon, authenticated;
grant execute on function public.reset_run(uuid) to anon, authenticated;
