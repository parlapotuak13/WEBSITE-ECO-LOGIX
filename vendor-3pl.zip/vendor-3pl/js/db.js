// Lapisan database: semua urusan Supabase ada di sini, app.js tidak perlu tahu detailnya.
const Store = (() => {
  const cfg = window.APP_CONFIG || window.ECOLOGIX_CONFIG || {};
  const ID = cfg.VENDOR_ID || 'eco-hemat';
  const ready = cfg.SUPABASE_URL && cfg.SUPABASE_ANON_KEY &&
    !cfg.SUPABASE_URL.startsWith('ISI_') && !cfg.SUPABASE_ANON_KEY.startsWith('ISI_');
  let client = null;

  async function init(onRemote) {
    if (!ready || !window.supabase) return 'lokal';
    try {
      client = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
      const { data, error } = await client.from('vendor_state').select('data').eq('id', ID).maybeSingle();
      if (error) throw error;
      if (data && data.data) onRemote(data.data);
      client.channel('vendor-' + ID)
        .on('postgres_changes', { event: '*', schema: 'public', table: 'vendor_state', filter: 'id=eq.' + ID },
          p => { if (p.new && p.new.data) onRemote(p.new.data); })
        .subscribe();
      return 'db';
    } catch (e) {
      console.warn('Database tidak bisa dipakai, beralih ke mode lokal:', e);
      client = null;
      return 'lokal';
    }
  }
  async function save(d) {
    const { error } = await client.from('vendor_state').upsert({ id: ID, data: d, updated_at: new Date().toISOString() });
    if (error) throw error;
  }
  async function load() {
    const { data, error } = await client.from('vendor_state').select('data').eq('id', ID).maybeSingle();
    if (error) throw error;
    return data && data.data;
  }
  return { init, save, load, get remote() { return !!client; } };
})();
