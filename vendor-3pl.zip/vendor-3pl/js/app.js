(() => {
const $ = id => document.getElementById(id);
const KEY = 'ecologix-vendor-v1';
const DEF = {sharing:true,threshold:.75,detour:2,area:true,volume:true,weight:true,decision:'pending',decidedAt:null,syncAt:null,history:[]};
const REQ = {pkgs:12,delta:.82,detour:2};
const A = {max:30,used:12};
const fmtN = (n,d=0) => n.toLocaleString('id-ID',{minimumFractionDigits:d,maximumFractionDigits:d});
const rp = n => 'Rp ' + fmtN(n);
const clock = t => t ? new Date(t).toLocaleTimeString('id-ID',{hour:'2-digit',minute:'2-digit',hour12:false}) : 'hh:mm';
const day = t => new Date(t).toLocaleString('id-ID',{day:'numeric',month:'short',hour:'2-digit',minute:'2-digit',hour12:false});

let S = {...DEF}, mode = 'lokal', writeErr = '';

try { const raw = localStorage.getItem(KEY); if (raw) S = {...DEF, ...JSON.parse(raw)}; } catch(e) {}

function persist() {
  try { localStorage.setItem(KEY, JSON.stringify(S)); } catch(e) {}
  if (Store.remote) Store.save(S).then(() => { writeErr = ''; render(); })
    .catch(e => { writeErr = 'Gagal menyimpan ke database: ' + (e && e.message || 'error') + '. Data hanya tersimpan di perangkat ini.'; render(); });
}

// Aturan: kapan permintaan boleh disetujui
function blocker() {
  if (!S.sharing) return 'Aktifkan “Ikut Load-Sharing” dulu.';
  if (REQ.delta < S.threshold) return 'Kemiripan rute (δ = 0,82) di bawah ambang δ = ' + fmtN(S.threshold,2) + '.';
  if (REQ.detour > S.detour) return 'Jarak memutar 2 km melebihi batas maksimum ' + fmtN(S.detour,1) + ' km.';
  if (A.used + REQ.pkgs > A.max) return 'Kapasitas Kurir A tidak cukup.';
  return '';
}

function render() {
  const ok = S.decision === 'approved';
  const status = ok ? 'Kolaborasi aktif' : S.decision === 'rejected' ? 'Rute langsung' : 'Menunggu keputusan';
  const used = A.used + (ok ? REQ.pkgs : 0);
  const load = Math.round(used / A.max * 100), load0 = Math.round(A.used / A.max * 100), load1 = Math.round((A.used + REQ.pkgs) / A.max * 100);
  const co0 = 2.52, co1 = +(2.52 - .70).toFixed(2), c0 = 45000 / 12, c1 = 68600 / 2 / 12;
  $('st').textContent = status; $('rq').innerHTML = '<span>Status</span><span>' + status + '</span>';
  $('m-load').textContent = load0 + '% → ' + load1 + '%'; $('m-load2').textContent = 'Saat ini: ' + load + '%';
  $('m-vmt').textContent = '36 → 26 km'; $('m-vmt2').textContent = 'Gabungan 2 vendor (Kurir A: 18→20 km).';
  $('m-co2').textContent = fmtN(co0,2) + ' → ' + fmtN(co1,2) + ' kg'; $('m-co22').textContent = 'Saat ini: ' + fmtN(ok ? co1 : co0,2) + ' kg';
  $('m-cost').textContent = rp(Math.round(c0)) + ' → ' + rp(Math.round(c1)); $('m-cost2').textContent = 'Saat ini: ' + rp(Math.round(ok ? c1 : c0)) + ' per paket';
  $('a-d').textContent = used + ' dari ' + A.max + ' paket · ' + load + '%';
  $('a-f').style.width = load + '%'; $('a-pb').setAttribute('aria-valuenow', load);
  $('a-r').textContent = 'V_rem = V_max − V_used = ' + A.max + ' − ' + used + ' = ' + (A.max - used) + ' paket';
  $('tb').innerHTML = '<tr><th>Jarak</th><td>18 km</td><td>20 km</td></tr><tr><th>CO₂ gabungan</th><td>' + fmtN(co0,2) + ' kg</td><td>' + fmtN(co1,2) + ' kg</td></tr><tr><th>Load factor A</th><td>' + load0 + '%</td><td>' + load1 + '%</td></tr><tr><th>Biaya/paket</th><td>' + rp(Math.round(c0)) + '</td><td>' + rp(Math.round(c1)) + '</td></tr>';
  const t = ok ? S.decidedAt : null;
  $('h1').textContent = 'Kilat Raya → Hub ✓ jam ' + clock(t); $('h2').textContent = 'Hub → Eco Hemat ✓ jam ' + clock(t);
  $('hist').innerHTML = S.history.length ? S.history.slice().reverse().map(h => '<li>' + day(h.at) + ' · ' + (h.d === 'approved' ? 'Disetujui' : 'Ditolak') + '</li>').join('') : '<li class="muted" style="list-style:none;margin-left:-18px">Belum ada keputusan.</li>';
  const ae = document.activeElement;
  [['sharing','checked'],['area','checked'],['volume','checked'],['weight','checked']].forEach(([k,p]) => { $(k)[p] = S[k]; });
  if (ae !== $('threshold')) $('threshold').value = S.threshold;
  if (ae !== $('detour')) $('detour').value = S.detour;
  $('th-o').textContent = 'δ = ' + fmtN(S.threshold,2);
  const b = blocker();
  $('ok').disabled = !!b;
  const why = $('why'); why.hidden = !(b || writeErr); why.textContent = writeErr || b;
  $('dbst').textContent = mode === 'db' ? 'Database: tersambung (data tersimpan di server)' : 'Database: tidak tersedia (mode lokal di perangkat ini)';
  $('sync').textContent = 'Sinkron terakhir: ' + (S.syncAt ? clock(S.syncAt) : 'Belum sinkron');
  const names = {area:'Area tujuan',volume:'Volume',weight:'Bobot'};
  $('enc').innerHTML = ['area','volume','weight'].map(k => '<li>' + (S[k] ? '🔒 ' + names[k] + ' · terenkripsi' : '— ' + names[k] + ' · tidak dibagikan') + '</li>').join('') + '<li class="muted">— Nama penerima · tidak dibagikan</li>';
}

function decide(d) {
  if (d === 'approved' && blocker()) return render();
  S.decision = d; S.decidedAt = d === 'approved' ? Date.now() : null;
  S.history = S.history.concat({d, at: Date.now()}).slice(-10);
  persist(); render();
}
function show(tab) {
  document.querySelectorAll('main section').forEach(s => s.hidden = s.id !== 'p-' + tab);
  document.querySelectorAll('nav button').forEach(b => b.classList.toggle('on', b.dataset.t === tab));
  window.scrollTo({top:0});
}
document.querySelectorAll('nav button').forEach(b => b.onclick = () => show(b.dataset.t));
$('ok').onclick = () => decide('approved');
$('no').onclick = () => decide('rejected');
['sharing','area','volume','weight'].forEach(k => $(k).onchange = e => { S[k] = e.target.checked; persist(); render(); });
$('threshold').oninput = e => { S.threshold = Number(e.target.value); render(); };
$('threshold').onchange = () => persist();
$('detour').onchange = e => { S.detour = Math.max(0, Math.min(20, Number(e.target.value) || 0)); persist(); render(); };
$('syncb').onclick = async () => {
  if (Store.remote) { try { const d = await Store.load(); if (d) S = {...DEF, ...d}; } catch(e) {} }
  S.syncAt = Date.now(); persist(); render();
};
$('reset').onclick = () => { S = {...DEF, syncAt: Date.now()}; writeErr = ''; persist(); render(); show('dashboard'); };

render();

// Sambungkan ke database (jika belum diisi config.js, otomatis mode lokal)
Store.init(d => { S = {...DEF, ...d}; render(); }).then(m => { mode = m; render(); });
})();
